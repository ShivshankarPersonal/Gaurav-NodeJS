#!/usr/bin/env bash

rm -rf .git

echo "installing the toolbox"
sudo npm install -g hs-toolbox

echo "installing the toolbox"
hs-installer install
node scripts/setup

echo "installing the toolbox"
pushd ./agent
hs-installer install
popd
