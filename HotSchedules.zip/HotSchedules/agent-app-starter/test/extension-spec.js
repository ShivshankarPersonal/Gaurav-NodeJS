var assert = require('chai').assert;
var ext    = require('../lib/local-plugins');
var tools  = require('agent-testing-tools')();

describe('Local Plugins', function() {

    it('should load', function () {
        assert.ok(ext, 'no extension available');
    });

    describe('Metadata', function () {

        it('should have a name', function () {
            assert.ok(ext.name, 0, 'has no depth');
            assert.isString(ext.version)
        });

        it('should have a version', function () {
            assert.ok(ext.version);
            assert.isString(ext.version)
        });
        it('should have an attach point', function () {
            assert.ok(ext.attach, 'is not idle');
            assert.isFunction(ext.attach)
        });
    });

    describe('Contents', function () {

        var err, plugins;

        before(function(done){
            tools.loadExtension(ext, {}, function(_err, _plugins) {
                err = _err;
                plugins = _plugins;
                done();
            })
        });

        it('should not produce an error', function () {
            assert.isFalse(!!err);
        });

        it('should load the plugins', function () {
            assert.ok(plugins);
        });

    });

});
