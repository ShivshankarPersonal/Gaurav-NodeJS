var assert = require('chai').assert;
var ext    = require('../lib/local-plugins');
var tools  = require('agent-testing-tools')();

describe('Local Facts Handler', function() {

    var err, plugins;

    before(function(done){
        tools.loadExtension(ext, {}, function(_err, _plugins) {
            err = _err;
            plugins = _plugins;
            done();
        })
    });

    describe('Plugin Availability', function () {

        it('should exist', function () {
            assert.ok(plugins.local.facts.check)
        });

        it('should be a function', function () {
            assert.isFunction(plugins.local.facts.check)
        });

    });

});
