var assert = require('chai').assert;
var ext    = require('../lib/local-plugins');
var tools  = require('agent-testing-tools')();

describe('JSON Middleware', function() {

    var err, plugins;

    before(function(done){
        tools.loadExtension(ext, {}, function(_err, _plugins) {
            err = _err;
            plugins = _plugins;
            done();
        })
    });

    describe('Plugin Availability', function () {

        it('should exist', function () {
            assert.ok(plugins.local.filters.json)
        });

        it('should be a function', function () {
            assert.isFunction(plugins.local.filters.json)
        });

    });

    describe('Object Input', function () {

        var filter;

        before(function(){
            filter = tools.createFilter(plugins.local.filters.json, {})
        });

        it('should produce an json string', function (done) {
            filter({/* input */}, function(err, msg){
                console.log(msg);
                assert.ok(msg);
                assert.isString(msg);
                assert.deepEqual(msg, "{}");
                done();
            })
        });


    });

});
