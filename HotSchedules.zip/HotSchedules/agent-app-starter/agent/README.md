# agent-cli

Commandline Interface for the Agent

## Getting Started
Install the module with: `npm install agent-cli`

```javascript
var agent_cli = require('agent-cli');
agent_cli.awesome(); // "awesome"
```

## Documentation
_(Coming soon)_

## Examples
_(Coming soon)_

## Contributing
In lieu of a formal styleguide, take care to maintain the existing coding style. Add unit tests for any new or changed functionality. Lint and test your code using [Grunt](http://gruntjs.com/).

## Release History
_(Nothing yet)_

## License
Copyright (c) 2014 bgaffney314  
Licensed under the Apache2 license.
