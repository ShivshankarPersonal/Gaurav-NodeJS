require('shelljs/global');

var fs   = require('fs');
var os   = require('os');
var path = require('path');
var isWin = /^win/.test(process.platform);

var args = process.argv;
var force = false;

if(args[2] === '-f' || args[2] === '--force'){
    force = true;
}

if(test('-e', './agent')){
    if(force) {
        rm('-rf', './agent');
    } else {
        console.log('refusing the setup: an agent already exists use --force or -f to recreate the local agent');
        process.exit(1);
    }
}

console.log('Installing the dependencies ...');

exec('hs-installer install', function(code, stdout, stderr) {

    console.log('Installing the agent ...');

    exec('hs-agent-builder create-agent agent', function (code, stdout, stderr) {

        if(code !== 0){
            console.log('failed to create the agent');
            process.exit(1);
        }

        var json = JSON.parse(cat('./agent/agent.json'));
        var relative_input = isWin ? '.\\input' : './input';
        var relative_module = isWin ? '..\\' : '../';

        console.log('creating the input directory %s ...', relative_input);
        mkdir('-p', relative_input);

        json.apps = {
            "local": {
                "module": relative_module,
                "enabled": true,
                "logger": {
                    "level": "verbose",
                    "filename": "local.log"
                },
                "settings": [
                    {
                        "property": "data_dir",
                        "value": relative_input
                    }
                ]
            }
        };

        var agent_json = JSON.stringify(json, null, '  ');

        if (isWin) {
            agent_json = agent_json.replace(/\n/g, '\r\n');
        }

        fs.writeFile('./agent/agent.json', agent_json, function (err) {
            console.log('setup complete');
        });
    });

});
