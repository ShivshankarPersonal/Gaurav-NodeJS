require('shelljs/global');

rm('-rf', 'agent/.storage');
rm('-rf', 'agent/logs');
