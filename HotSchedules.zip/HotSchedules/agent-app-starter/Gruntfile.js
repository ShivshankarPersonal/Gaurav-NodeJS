module.exports = function(grunt) {

	// Add the grunt-mocha-test tasks.
	grunt.loadNpmTasks('grunt-contrib-copy');
	grunt.loadNpmTasks('grunt-contrib-clean');
	grunt.loadNpmTasks('grunt-bump');
	grunt.loadNpmTasks('grunt-mkdir');
	grunt.loadNpmTasks('grunt-exec');
	grunt.loadNpmTasks('grunt-bump');
	grunt.loadNpmTasks('grunt-sloc');
	grunt.loadNpmTasks('grunt-conventional-changelog');
    grunt.loadNpmTasks('grunt-mocha-test');
    grunt.loadNpmTasks('grunt-mocha-istanbul');
    grunt.loadNpmTasks('grunt-jsdoc');

	var BUILD_DIR   = './dist';
    var PUBLIC_DIR  = './dist/public';
	var RELEASE_DIR = './dist';

	grunt.initConfig({

		pkg : grunt.file.readJSON( 'package.json' ),

//		Configure a mochaTest task
        mochaTest: {
			test: {
				options: {
					reporter: 'mochawesome',
                    quiet   : false
				},
				src: ['test/**/*.js']
			}
		},
		//- Build Release Tasks
		mkdir: {
			all: {
				options: { create: [BUILD_DIR, PUBLIC_DIR] }
			},
            projects: {
                options: { create: ['input'] }
            }
		},
		//- Clean up previous builds
		clean: {
			build: {
				src: [ BUILD_DIR ]
			},
			coverage: {
				src: ['coverage/']
			}
		},
		//- Copy the build
		copy: {
			build: {
				files: [
					{ src: [ 'package.json'      ], dest: BUILD_DIR, expand: true },
					{ src: [ 'index.js'          ], dest: BUILD_DIR, expand: true },
					{ src: [ 'README.md'         ], dest: BUILD_DIR, expand: true },
                    { src: [ 'LICENSE'           ], dest: BUILD_DIR, expand: true },
					{ src: [ 'lib/**'            ], dest: BUILD_DIR, expand: true }
				]
			}
		},
		exec: {
			lsr        : { cmd: 'ls -la', cwd: 'release' }
			, npm_release: { cmd: 'npm install --production', cwd: 'release' }
			, more_pkg   : { cmd: 'more package.json', cwd: 'release' }
			, prune_pkg  : { cmd: function(){
				var rPkg = grunt.file.readJSON( 'package.json' );
				delete rPkg.devDependencies;
				delete rPkg.scripts;
				grunt.file.write(BUILD_DIR + '/package.json', JSON.stringify(rPkg, null, 4));
				return "";
			}},
            reset        : { cmd: 'node scripts/reset'  , cwd: __dirname },
            install      : { cmd: 'node scripts/install', cwd: __dirname },
            init         : { cmd: 'node scripts/init'   , cwd: __dirname }
		},
		sloc: {
			options: {
				reportDetail: true
			},
			core: {
				files: {
					'lib': [ '**' ]
				}
			},
			dist: {
				files: {
					'lib': [ '**' ]
				}
			},
			tests: {
				files: {
					'test': [ '**' ]
				}
			}
		},
		//Bump the version number
		bump: {
			options: {
				files: ['package.json'],
				updateConfigs: [],
				commit: true,
				commitMessage: 'Release v%VERSION%',
				commitFiles: ['package.json'],
				createTag: true,
				tagName: 'v%VERSION%',
				tagMessage: 'Version %VERSION%',
				push: true,
				pushTo: 'origin',
				gitDescribeOptions: '--tags --always --abbrev=1 --dirty=-d'
			}
		},

        ///COVERAGE DETAILS
        mocha_istanbul: {
            coverage: {
                src: 'test', // a folder works nicely
                options: {
                    mask: '*.js',
                    reportFormats: ['cobertura','lcov']
                }
            },
            coveralls: {
                src: ['test'], // multiple folders also works
                options: {
                    coverage:true, // this will make the grunt.event.on('coverage') event listener to be triggered
                    check: {
                        lines: 30,
                        statements: 30
                    },
                    root: './lib', // define where the cover task should consider the root of libraries that are covered by tests
                    reportFormats: ['cobertura','lcov']
                }
            }
        },
        istanbul_check_coverage: {
            default: {
                options: {
                    coverageFolder: 'coverage*', // will check both coverage folders and merge the coverage results
                    check: {
                        lines: 20,
                        statements: 20
                    },
                    reportFormats: ['lconv']
                }
            }
        },

        jsdoc : {
            dist: {
                src: ['README.md', './index.js', './lib/*.js'],
                options: {
                    destination: 'doc',
                    template: "node_modules/ink-docstrap/template",
                    configure: "./jsdoc.conf.json"
                }
            }
        }
	});

	grunt.registerTask('count',
		'count the code in the core lib',
		['sloc:core']
	);

	//Build a Basic Distribution
	grunt.registerTask('build',
		'Compiles all of the assets and copies the files to the build directory.',
		[ 'clean', 'mkdir', 'copy', 'exec:prune_pkg', 'sloc:dist']
	);

    grunt.registerTask('default','mochaTest');


    grunt.event.on('coverage', function(lcovFileContents, done){
        // Check below on the section "The coverage event"
        done();
    });

    grunt.registerTask('reset'      , ['exec:reset']);
    grunt.registerTask('setup'      , ['exec:install', 'exec:init']);

    grunt.registerTask('doc'        , ['jsdoc:dist']);
    grunt.registerTask('coverage'   , ['mocha_istanbul:coverage']);


	grunt.registerTask('release',
		'Creates a release',
		[ 'clean', 'mkdir', 'copy', 'bump', 'exec:prune_pkg']
	);
};
