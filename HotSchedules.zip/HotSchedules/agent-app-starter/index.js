var pkg  = require('./package.json');

module.exports = {

    name       : pkg.name        || 'default-app-name',
    version    : pkg.version     || '0.0.0',
    description: pkg.description || 'application description',
    publisher  : 'YOUR_COMPANY_HERE',

    /* --Settings: [ Array of Objects ]
        Static Configuration Data
     */
    settings: [
        //{property  : 'date_dir' , value: 'D:/Projects/IoT Platform/test-app/file.txt'}
    ],

    /* --Extensions [Array of Objects]
        An extension loads a set plugins that can be used in the application
        from either an application specific source or a external library
     */
    extensions: [
        {module: './lib/local-plugins'}
    ],

    /* --Service
        A service defines injectable behavior or state that can be used/shared
        across components.
     */
    services: [
        {
            name    : 'cloud',
            provider: 'connection:resources'
        },
    ],

    /* --Counters
        Basic Metrics Counters for Events
     */
    counters: {

    },

    /* --Sources
     A source defines an external event source observed by the application.
     */
    sources: [
    ],

    /* --Pipelines
        A pipeline is a set of functions that process a message/data a sequence of discrete steps
     */
    pipelines: [
        {
            //@Brian  - how do i get the agent_id in here?
            name: 'AdaptFromSource',
            subscriptions: ['file:created', 'announce:file', 'ready'],
            steps: [
                //@todo - this should be coming from the source ... we should use a file pump
                {fn: function(input, next) {
                    console.log('Activated')
                    next(null, input)
                }},
                {fn: function(input, next) {
                    var self = this;
                    //@note - this is going away but safe for backward compatibility
                    self.conn 	 = self.conn.getSuperagent ? self.conn.getSuperagent() : self.conn;
                    self.conn.file.uploadContent('your/file/here', 'This is some file content',
                        function (err, doc, res) {
                            if(!err){
                                console.log('POSTED ', res.statusCode, res.request.url);
                            }
                            next(null, input);
                        }
                    )
                }, props: {
                    conn   : '$service:cloud'
                }}
            ],
            success: 'resource:processed',
            failure : 'error:saving'
        }
    ],

    /*
     Handlers (might be better renamed as actors)
     A Handler subscribes to specific events and processes the messages
     */
    handlers: [
    ],

    /**
     * Init
     * A Routine to run prior to activating sources
     */
    init: function (initialized) {
        var app = this;
        console.log('%s started', app.name);
        app.logger.info('---- %s started -----', app.name);
        initialized && initialized();
    }
};
