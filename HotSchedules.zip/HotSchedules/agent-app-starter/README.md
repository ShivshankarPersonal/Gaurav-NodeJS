# Starter App

## Setup Procedure
To use agent applications, you must first install the global tools

* NodeJs
* NPM
* hs-toolbox
* hs-agent-tools

### Windows Setup

The following steps should be executed from a command terminal

````
>  git clone git@bitbucket.org:redbookplatform/agent-app-starter.git
>  cd agent-app-starter
>  setup.bat
````

### POSIX Setup

````
$  git clone git@bitbucket.org:redbookplatform/agent-app-starter.git
$  cd agent-app-starter
$  setup.sh
````

## Project Structure

The above steps will setup a sample project scaffolding for you. The directory

### Local Machine Scaffolding

__[+]__ denotes a directory that should be managed by a VCS
__[-]__ denotes a local directory that should be unmanaged by a VCS

````
/<install_dir>
 |-/agent               [-]     # Local Agent
 |-/data                [+]     # Sample Data Files
 |-/input               [-]     # Local Input Folder
 |-/node_modules        [-]     # External Dependencies
 |-/lib                 [+]     # Local Application Components
 |-/settings            [+]     # Declarative Settings (optional)
 |-scripts              [+]     # Project ShellJS Scripts
 |-test                 [+]     # automated tests
 |-.gitignore.js        [+]     # files to ignore for version control purposes
 |-Grunt.js             [+]     # project workflow scripts
 |-index.js             [+]     # application file
 |-package.json         [+]     # node manifest file
 |-README.md            [+]     # readme file
````

### Development Project

````
/<project_dir>
 |-/data                        # Sample Data Files
 |-/lib                         # Local Application Components
    |-/handlers                 # Local Handlers       (optional)
    |-/middlewares              # Local Middleware     (optional)
    |-/services                 # Local Services       (optional)
    |-/sources                  # Local Services       (optional)
    |-/util                     # Local Services       (optional)
    |-local-plugins.js          # Local Extenstion     (optional)
 |-/settings                    # Declarative Settings (optional)
 |-/scripts                     # Helpful ShellJS Scripts
    |-setup.js                  # setup the expected project structure 
    |-reset.js                  # clear logs and storage 
 |-/test                        # mocha test files
    |-*.js                      # test files
 |-.gitignore.js                # files to ignore for version control purposes
 |-Grunt.js                     # project workflow scripts
 |-index.js                     # application file
 |-package.json                 # node manifest file
````

##Binding Process

In order to connect your agent to the cloud, you will need to

# License
Copyright (c) 2016 HotSchedules Inc

Licensed under the Apache2 license.
