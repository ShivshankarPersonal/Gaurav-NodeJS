var express = require('express');
var log4js = require('log4js');
log4js.configure('./appConfig/log4js.json');
var log = log4js.getLogger("router");
log.trace("loaded router");
var router = express.Router();
var combineValidColumns = require("../models/combineValidColumns");
var salesTransaction = require("../models/salesTransaction");

var multer  = require('multer');
var upload = multer({ dest: 'uploads/' });
router.get('/combine', combineValidColumns.combine);
//uncomment later
//router.post('/insertIntoSalesAmount',salesTransaction.insertIntoSalesAmount);



/**
 * Handle DBF file upload requests
 */
var fileUpload = require("../controllers/readDBFFile");
router.post("/fileUpload", fileUpload.read);

/**
 * Handle exception
 */

var handleException = require("../controllers/exceptionHandling");
router.get("/handleException", handleException.handle);
module.exports = router;

/**
 * Process DBF files in Batch
 */
//var app = express();
//var processDBFFilesInBatch = require("../controllers/processDBFFilesInBatch");
//app.post("/uploadFileInBatch", upload.single('file'), processDBFFilesInBatch.listenAndStoreInDir)
//router.post('/uploadFileInBatch', function (req, res, next) {
//    // req.file is the `avatar` file
//    // req.body will hold the text fields, if there were any
//    console.log(req.files)
//})