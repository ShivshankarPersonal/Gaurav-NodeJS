var processDBFFilesInBatch = {};
var later = require('later');
var multer = require('multer');
var upload = multer({dest: 'uploads/'});
var S = require('string');
var fs = require("fs");
var fse = require('fs-extra');

/**
 * Batch Process Stored Files, remove after completion of processing else throw error
 */

processDBFFilesInBatch.processFilesInBatch = function () {
    var fs = require("fs");
    var obj = JSON.parse(fs.readFileSync('appConfig/bodhiAPI.json', 'utf8'));
    var posFetchCycleTime = obj.posFetchCycleTime;
    var dbfCopyCycleTime = obj.dbfCopyCycleTime;
    var p = obj.allDBFFiles;

    //copyAllDBFFilesToTempDirectory();
    var schedDirectoryCopy = later.parse.recur().every(dbfCopyCycleTime).minute(),
        t1 = later.setInterval(copyAllDBFFilesToTempDirectory, schedDirectoryCopy);



    var sched = later.parse.recur().every(posFetchCycleTime).minute(),
        t = later.setInterval(processAllDBFFiles, sched);
    //processAllDBFFiles();


    //Process All DBF files in an interval of 5min
    function processAllDBFFiles(){
        /**
         * Process Employee Position Table
         */
        var processEmpPosition = require("../controllers/processEmployeePositionData");
        processEmpPosition.readDBFnPostToCloud();
        /**
         * Process process Emp Data Table
         */
        var processEmpData = require("../controllers/processEmpData");
        processEmpData.readDBFnPostToCloud();
        ///**
        // * Process Employee Position Table
        // */
        var processRevenueCenter = require("../controllers/processRevenueCenter");
        processRevenueCenter.readDBFnPostToCloud();
        /////**
        //// * Process process Sales Transaction Table
        //// */
        var processSalesTransaction = require("../controllers/processSalesTransaction");
        processSalesTransaction.readDBFnPostToCloud();
        /////**
        //// * Process process Sales Category Table
        //// */
        var processSalesCategory = require("../controllers/processSalesCategory");
        processSalesCategory.readDBFnPostToCloud();
        ///**
        // * Process process Sales Item Table
        // */
        var processSalesItem = require("../controllers/processSalesItem");
        processSalesItem.readDBFnPostToCloud();
        ///**
        // * Process processSalesJob Table
        // */
        var processSalesJob = require("../controllers/processSalesJob");
        processSalesJob.readDBFnPostToCloud();
        ///**
        // * Process process Time Card Table
        // */
        var processTimeCard = require("../controllers/processTimeCard");
        processTimeCard.readDBFnPostToCloud();
    }
    function copyAllDBFFilesToTempDirectory(){
        try {
            var path = require("path");
            //Path of C Drive
            var p = "allDBFFiles";
            fs.readdir(p, function (err, files) {
                debugger;
                if (err) {
                    throw err;
                }
                files.map(function (file) {
                    return path.join(p, file);
                }).filter(function (file) {
                    return fs.statSync(file).isFile();
                }).forEach(function (file) {
                    console.log("%s (%s)", file, path.extname(file));
                    //Start reading files
                    //check file extension
                    var fileExtension = path.extname(file);
                    var filename = file.split('/')[1];
                    var createdOn = filename.split('.')[0].substr(-4);
                    if (file !== "temp/DBFFiles/.DS_Store") {
                        var d = new Date();
                        var year = d.getYear().toString().substr(1, 2);
                        var month = parseInt(d.getMonth()) + 1;
                        if (year === createdOn.substr(2, 3) && month === parseInt(createdOn.substr(0, 2))) {
                            fse.copy(file.toString(), 'temp/DBFFiles/' + filename, function (err) {
                                if (err) {
                                    return console.error(err)
                                } else {
                                    console.log("successfully copied!");
                                }
                            });
                        }
                    }
                    if (filename === "LOGIN16.DBF" || filename === "LOGIN16.dbf") {
                        fse.copy(file.toString(), 'temp/DBFFiles/' + filename, function (err) {
                            if (err) {
                                return console.error(err)
                            } else {
                                console.log("successfully copied!");
                            }
                        });
                    }
                });
            });
        } catch (e) {
        }
    }

    //function processDirectory() {
    //    try {
    //        var fs = require("fs");
    //        var path = require("path");
    //        var p = "temp/DBFFiles/";
    //        fs.readdir(p, function (err, files) {
    //            if (err) {
    //                throw err;
    //            }
    //            files.map(function (file) {
    //                return path.join(p, file);
    //            }).filter(function (file) {
    //                return fs.statSync(file).isFile();
    //            }).forEach(function (file) {
    //                console.log("%s (%s)", file, path.extname(file));
    //                //Start reading files
    //                //check file extension
    //                var fileExtension = path.extname(file);
    //                //if(fileExtension === '.json'){
    //                if (file !== "temp/DBFFiles/.DS_Store") {
    //                    //read file
    //                    var jsonfile = require('jsonfile')
    //                    var util = require('util')
    //                    console.log(jsonfile.readFileSync(file));
    //                    //after successfull reading delete file from temp folder
    //                    fs.unlinkSync(file);
    //                }
    //            });
    //        });
    //    } catch (e) {
    //        console.log("error in this file" + file);
    //    }
    //}
};

module.exports = processDBFFilesInBatch;
