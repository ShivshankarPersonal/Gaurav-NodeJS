var processEmpPosition = {};
var log4js = require('log4js');
log4js.configure('./appConfig/log4js.json');
var log = log4js.getLogger("exception Handling file");
var request = require('request');
var fse = require('fs-extra');
var api = require('bodhi-driver-superagent');
var Parser = require('node-dbf');


var fs = require("fs");
var obj = JSON.parse(fs.readFileSync('appConfig/bodhiAPI.json', 'utf8'));
var revenueCenter = obj.revenueCenter;
var userName = obj.userName;
var userPassword = obj.userPassword;
var organization = obj.organization;
var client = api.createUserClient(userName, userPassword, organization);
/**
 * readDBFnPostToCloud
 * @param req
 * @param res
 */
processEmpPosition.readDBFnPostToCloud = function (req, res) {
    //Read DBF file
    try {

        //Read files from directory
        var path = require("path");
        //Path of C Drive
        //var p = "allDBFFiles";
        var p = "/Volumes/StudyMaterials/Workspace/Gaurav/HotSchedule/temp";
        fs.readdirSync(p, function (err, files) {
            if (err) {
                throw err;
            }
            files.map(function (file) {
                return path.join(p, file);
            }).filter(function (file) {
                return fs.statSync(file).isFile();
            }).forEach(function (file) {
                console.log("%s (%s)", file, path.extname(file));
                //Start reading files
                //check file extension
                var fileExtension = path.extname(file);
                //if(fileExtension === '.json'){
                if (file !== "temp/DBFFiles/.DS_Store") {
                    var filename = file.split('/')[1];
                    var createdOn = filename.split('.')[0].substr(-4);
                    var d = new Date();
                    var year = d.getYear().toString().substr(1, 2);
                    var month = parseInt(d.getMonth()) + 1;
                    if (year === createdOn.substr(2, 3) && month === parseInt(createdOn.substr(0, 2))) {
                        fse.copy(file.toString(), 'temp/DBFFiles/' + filename, function (err) {
                            if (err) {
                                return console.error(err)
                            } else {
                                log.log("successfully copied!");
                            }
                        });
                    }
                }
            });
        });

        //Process new directory - dbf files
        var record;
        //var Parser = require('bodhi-dbf');
        var parserEmp = new Parser('./temp/DBFFiles/EMPLOYEE0516.DBF');
        parserEmp.on('start', function (p) {
            log.log('dBase file parsing has started');
        });

        parserEmp.on('header', function (h) {
            log.log('dBase file header has been parsed');
        });


        parserEmp.on('record', function (record) {
            //read login dbf file

            var jsonObj = {
                "store_id": "557605fc4c32e071180a4604",
                "instore_name": "BAR",
                "display_name": "BAR",
                "instore_id": "1",
                "sys_id": "55c4eaabd539ec3ef23618cf"
            };

            client.post(revenueCenter, jsonObj, function (err, json, res) {
                console.log(res.statusCode);
                client.get(revenueCenter, function (err, json, res) {
                    console.log(err, res.statusCode, json.length);
                })
            });

        });

        parserEmp.on('end', function (p) {
            //log.log('Finished parsing the dBase file');
        });
        parserEmp.parse();


        res.send("Successfully Read .dbf file");
    } catch (e) {
        log.error("Failed to read file and error is " + e);
    }


};

module.exports = processEmpPosition;
