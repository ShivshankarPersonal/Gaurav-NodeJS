var processEmpPosition = {};
var log4js = require('log4js');
log4js.configure('./appConfig/log4js.json');
var log = log4js.getLogger("exception Handling file");
var request = require('request');
var fse = require('fs-extra');
var api = require('bodhi-driver-superagent');
var Parser = require('node-dbf');

var fs = require("fs");
var obj = JSON.parse(fs.readFileSync('appConfig/bodhiAPI.json', 'utf8'));
var salesItem = obj.salesItem;
var userName = obj.userName;
var userPassword = obj.userPassword;
var organization = obj.organization;
var client = api.createUserClient(userName, userPassword, organization);
/**
 * readDBFnPostToCloud
 * @param req
 * @param res
 */
processEmpPosition.readDBFnPostToCloud = function (req, res) {
    //Read DBF file
    try {

        //Read files from directory
        var path = require("path");
        //Path of C Drive
        //var p = "allDBFFiles";
        var p = "/Volumes/StudyMaterials/Workspace/Gaurav/HotSchedule/temp";
        fs.readdirSync(p, function (err, files) {
            if (err) {
                throw err;
            }
            files.map(function (file) {
                return path.join(p, file);
            }).filter(function (file) {
                return fs.statSync(file).isFile();
            }).forEach(function (file) {
                console.log("%s (%s)", file, path.extname(file));
                //Start reading files
                //check file extension
                var fileExtension = path.extname(file);
                //if(fileExtension === '.json'){
                if (file !== "temp/DBFFiles/.DS_Store") {
                    var filename = file.split('/')[1];
                    var createdOn = filename.split('.')[0].substr(-4);
                    var d = new Date();
                    var year = d.getYear().toString().substr(1, 2);
                    var month = parseInt(d.getMonth()) + 1;
                    if (year === createdOn.substr(2, 3) && month === parseInt(createdOn.substr(0, 2))) {
                        fse.copy(file.toString(), 'temp/DBFFiles/' + filename, function (err) {
                            if (err) {
                                return console.error(err)
                            } else {
                                log.log("successfully copied!");
                            }
                        });
                    }
                }
            });
        });

        //Process new directory - dbf files
        var record;
        //var Parser = require('bodhi-dbf');
        var parserEmp = new Parser('./temp/DBFFiles/sls0516.dbf');
        parserEmp.on('start', function (p) {
            log.log('dBase file parsing has started');
        });

        parserEmp.on('header', function (h) {
            log.log('dBase file header has been parsed');
        });


        parserEmp.on('record', function (record) {
            //read login dbf file
            var parseSDET = new Parser('./temp/DBFFiles/sdet0516.dbf');
            //var parser = new Parser(‌‌req.files.file.data);

            parseSDET.on('start', function (p) {
                //log.log('dBase file parsing has started');
            });

            parseSDET.on('header', function (h) {
                //log.log('dBase file header has been parsed');
            });

            parseSDET.on('record', function (sdetrecord) {

                //uncomment this later
                //var d = new Date();
                //var year = d.getYear().toString().substr(1, 2);
                //var month = d.getMonth();
                //var date = d.getDate().toString();
                //var hours = d.getHours();
                //var min = d.getMinutes();
                //if (record.RAWOUTDATE.substr(0, 4) >= '20' + year && record.RAWOUTDATE.substr(4, 2) >= '0' + (month + 1).toString() && record.RAWOUTDATE.substr(6, 2) >= date && record.RAWOUTTIME.split(':')[0] >= hours.toString() && parseInt(record.RAWOUTTIME.split(':')[1]) >= (min - 5)) {
                //    console.log("Only Pushing latest record which are present in added in last 5min and record are : ====");
                //    console.log(record);
                //
                //
                //} else {
                //    console.log("Already Pushed Records are :====");
                //    console.log(record);
                //}

                if (record.BILL_NO && sdetrecord.BILL_NO && record.BILL_NO === sdetrecord.BILL_NO) {
                    //record.BILL_DATE+record.BILL_TIME
                    var jsonObj = {
                        "quantity": 1,
                        "order_id": ""+record.BILL_NO,
                        "order_number": record.BILL_NO,
                        "store_id": "557605fc4c32e071180a4604",
                        "business_day": record.BILL_DATE,
                        "net_total": {
                            "value": record.RECEIVED,
                            "code": "USD",
                            "scale": 2
                        },
                        //"timestamp": record.OPEN_TIME,
                        "timestamp": record.BILL_DATE+"T"+record.BILL_TIME+".000Z",
                        "transaction_id": ""+record.TRANS_ID,
                        "tax_id": "",
                        "tax_exempt": true,
                        "sales_category": {
                            "id": "5",
                            "name": "BAR MISC"
                        },
                        "sys_version": 1,
                        "sys_created_at": "2015-08-07T19:28:48.919Z",
                        "sys_created_by": "admin__bracco",
                        "sys_id": "55c506f1da31494548f4ae52"
                    };

                    client.post(salesItem, jsonObj, function (err, json, res) {
                        console.log(err);
                        client.get(salesItem, function (err, json, res) {
                            console.log(err, res.statusCode, json.length);
                        })
                    });
                }
            });
            parseSDET.on('end', function (p) {
                //log.log('Finished parsing the dBase file');
            });
            parseSDET.parse();
        });

        parserEmp.on('end', function (p) {
            //log.log('Finished parsing the dBase file');
        });
        parserEmp.parse();


        res.send("Successfully Read .dbf file");
    } catch (e) {
        log.error("Failed to read file and error is " + e);
    }


};

module.exports = processEmpPosition;
