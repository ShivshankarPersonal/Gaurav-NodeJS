var processDBFFilesInBatch = {};
var multer  = require('multer')
var upload = multer({ dest: 'uploads/' })
/**
 * Listen from Client and store in an temp directory
 */
processDBFFilesInBatch.listenAndStoreInDir = function(req, res, next){
console.log("received file")
};
/**
 * Batch Process Stored Files, remove after completion of processing else throw error
 */
processDBFFilesInBatch.processFilesInBatch = function () {

};

module.exports=processDBFFilesInBatch;
