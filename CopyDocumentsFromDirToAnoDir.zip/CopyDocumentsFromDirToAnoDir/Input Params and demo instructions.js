1. Change various values and insert. 
a=storeid9&b=Fri Mar 25 2016 15:18:56 GMT+0530 (IST)&c=FriDay&d=ord1&e=123&f=Fri Mar 25 2016 15:18:56 GMT+0530 (IST)