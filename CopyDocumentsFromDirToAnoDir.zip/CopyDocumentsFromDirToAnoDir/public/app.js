var app = angular.module("jetbrains", []);
app.controller("appCtrl", function ($http) {
    var app = this;
    var url = "http://localhost:3000";
    //fetchProducts();
    app.fetchProducts = function () {
        $http.get(url).success(
            function (response) {
                app.products = response;
            }
        );
    }
    app.copyProducts = function () {
        $http.get(url+'/copy').success(
            function (response) {
                app.backupProducts = response;
            }
        );
    }
    app.save = function (newProduct, storeId) {
        $http.post(url + '/add', {name: newProduct, storeId:storeId}).success(function (response) {
            app.fetchProducts
        });
    };
    app.getBackupData = function(){
        $http.get(url+'/getBackupData').success(
            function (response) {
                app.backupProducts = response;
            }
        );
    };
    app.CopyToCloud = function(){
        $http.get(url+'/copyToCloud').success(
            function(res){
                alert("Successfully received and will be copied at the specific time");
            }
        )
    }
    app.Combine = function(){
        $http.get(url+'/combine').success(
            function(res){
                alert("Successfully combined");
            }
        )
    }
    app.merge2Records = function(){
        $http.get(url+'/merge2Records').success(
            function(res){
                alert("Successfully combined");
            }
        )
    }


});