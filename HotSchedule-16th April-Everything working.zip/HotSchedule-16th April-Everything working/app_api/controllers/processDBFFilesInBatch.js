var processDBFFilesInBatch = {};
var later = require('later');
var multer = require('multer')
var upload = multer({dest: 'uploads/'});


/**
 * Listen from Client and store in an temp directory
 */
processDBFFilesInBatch.listenAndStoreInDir = function (req, res, next) {
    console.log("received file");
    res.send("received file");
};
/**
 * Batch Process Stored Files, remove after completion of processing else throw error
 */

processDBFFilesInBatch.processFilesInBatch = function () {
    var sched = later.parse.recur().every(1).minute(),
        t = later.setInterval(processDirectory, sched);

    function processDirectory() {
        try {
            var fs = require("fs");
            var path = require("path");
            var p = "temp/DBFFiles/";
            fs.readdir(p, function (err, files) {
                if (err) {
                    throw err;
                }
                files.map(function (file) {
                    return path.join(p, file);
                }).filter(function (file) {
                    return fs.statSync(file).isFile();
                }).forEach(function (file) {
                    console.log("%s (%s)", file, path.extname(file));
                    //Start reading files
                    //check file extension
                    var fileExtension = path.extname(file);
                    //if(fileExtension === '.json'){
                    if (file !== "temp/DBFFiles/.DS_Store") {
                        //read file
                        var jsonfile = require('jsonfile')
                        var util = require('util')
                        console.log(jsonfile.readFileSync(file));
                        //after successfull reading delete file from temp folder
                        fs.unlinkSync(file);
                    }
                });
            });
        } catch (e) {
            console.log("error in this file" + file);
        }
    }
};

module.exports = processDBFFilesInBatch;
