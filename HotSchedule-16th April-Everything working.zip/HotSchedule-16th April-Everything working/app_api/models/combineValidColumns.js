var mongoose = require("mongoose");
var log4js = require('log4js');
log4js.configure('./appConfig/log4js.json');
var log = log4js.getLogger("combine Valid column");
log.info("loaded combine Valid column");
var combineValidColumns = module.exports = {};
var validColumnSchema = new mongoose.Schema({
    city:String,
    pincode:Number,
    statename:String
});
var addressSchema = new mongoose.Schema({
    address:String
});

var ValidColumns = mongoose.model("ValidColumns", validColumnSchema);
var Address = mongoose.model("Address", addressSchema);

combineValidColumns.combine = function(req, res){
    var validColm = new ValidColumns({
        city:"Pune",
        pincode:123,
        statename:"Maha"
    });
    validColm.save(function(err){
        if (err) {
            log.error("failed" + err);
        } else {
            log.info("inserted record");
        }
    });

    var address = 0;
    ValidColumns.find(function(err,addres){
        var city = addres[0].city;
        var state = addres[0].statename;
        var pincodeis = addres[0].pincode;
        address=city+"-"+pincodeis+"-"+state;
        var address = new Address({
            address : address
        });
        address.save(function(err){
            if (err) {
                log.error("failed" + err);
            } else {
                log.info("inserted record");
            }
        });
    });
    //res.send();
};

//module.exports = combineValidColumns;