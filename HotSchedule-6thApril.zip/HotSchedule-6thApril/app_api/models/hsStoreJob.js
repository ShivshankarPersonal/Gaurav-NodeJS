var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var hssStoreJob = module.exports = {};


/**
 * HSSStoreJob Schema and Collection
 */
var hsStoreJobSchema = new Schema({
    instore_id : String,
    instore_name : String,
    store_id : String,
    regular_rate : Number,
    overtime_rate : Number,
    double_rate : Number

});

var HSStoreJob = mongoose.model("HSStoreJob", hsStoreJobSchema);


/**
 * HSStoreEmployee Schema and Collection
 */

var hsStoreEmployeeSchema = new Schema({
    address : String,
    email : String,
    employement_period : String,
//Please add columns here
});

var HSStoreEmployee = mongoose.model("HSStoreEmployee", hsStoreEmployeeSchema);


/**
 * HSStoreemployeeJob Schema and Collection
 */
 var hSStoreemployeeJobSchema = new Schema({
    store_id : String,
    employee_id : String
});

var HSStoreemployeeJob = mongoose.model("HSStoreemployeeJob", hSStoreemployeeJobSchema);


/**
 * HSRevenueCenter Schema and Collection
 */
var hSRevenueCenterSchema = new Schema({
    store_id : String,
});

var HSRevenueCenter = mongoose.model("HSRevenueCenter", hSRevenueCenterSchema);

/**
 * HSSalesCategory Schema and Collection
 */
var hSSalesCategorySchema = new Schema({
    store_id : String,
});

var HSSalesCategory = mongoose.model("HSSalesCategory", hSSalesCategorySchema);


/**
 * HSSalesDay Schema and Collection
 */
var hSSalesDaySchema = new Schema({
    store_id : String,
});

var HSSalesDay = mongoose.model("HSSalesDay", hSSalesDaySchema);

/**
 * HSSalesItem Schema and Collection
 */
 var hSSalesDaySchema = new Schema({
    store_id : String,
});

var HSSalesItem = mongoose.model("HSSalesItem", hSSalesDaySchema);


/**
 * HSVolumeDay Schema and Collection
 */
var hSVolumeDaySchema = new Schema({
    store_id : String,
});

var HSVolumeDay = mongoose.model("HSVolumeDay", hSVolumeDaySchema);


/**
 * HSVolumeItem Schema and Collection
 */
 var hSVolumeItemSchema = new Schema({
    store_id : String,
});

var HSVolumeItem = mongoose.model("HSVolumeItem", hSVolumeItemSchema);


/**
 * HSTimeCard Schema and Collection
 */
var hSTimeCardSchema = new Schema({
    store_id : String,
});

var HSTimeCard = mongoose.model("HSTimeCard", hSTimeCardSchema);

