var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var storeJob = module.exports = {};

/**
 * StoreJob Schema and Collection
 */
var storeJobSchema = new Schema({
    instore_id : String
});
var StoreJob = mongoose.model("StoreJob", storeJobSchema);

/**
 * Employee Schema and Collection
 */
var employeeSchema = new Schema({
    name : String
})
var Employee = mongoose.model("Employee", employeeSchema);

/**
 * EmployeePosition Schema and Collection
 */

var EmployeePositionSchema = new Schema({
    store_id : String
})
var EmployeePosition = mongoose.model("EmployeePosition", EmployeePositionSchema);

/**
 * RevenueCenter Schema and Collection
 */

var revenueCenterSchema = new Schema({
    store_id : String
})
var RevenueCenter = mongoose.model("RevenueCenter", revenueCenterSchema);

/**
 * SalesCategory Schema and Collection
 */

var salesCategorySchema = new Schema({
    store_id : String
})
var SalesCategory = mongoose.model("SalesCategory", salesCategorySchema);

/**
 * SalesItem Schema and Collection
 */

var salesItemSchema = new Schema({
    store_id : String
})
var SalesItem = mongoose.model("SalesItem", salesItemSchema);

/**
 * TimeCard Schema and Collection
 */

var TimeCardSchema = new Schema({
    store_id : String
})
var TimeCard = mongoose.model("TimeCard", TimeCardSchema);