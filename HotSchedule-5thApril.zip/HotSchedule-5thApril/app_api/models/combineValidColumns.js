var mongoose = require("mongoose");
var combineValidColumns = module.exports = {};
var validColumnSchema = new mongoose.Schema({
    city:String,
    pincode:Number,
    statename:String
});
var addressSchema = new mongoose.Schema({
    address:String
});

var ValidColumns = mongoose.model("ValidColumns", validColumnSchema);
var Address = mongoose.model("Address", addressSchema);

combineValidColumns.combine = function(req, res){
    var validColm = new ValidColumns({
        city:"Pune",
        pincode:123,
        statename:"Maha"
    });
    validColm.save(function(err){
        if (err){
            console.log("error");
        }else {
            console.log("saved")
        }
    });

    var address = 0;
    ValidColumns.find(function(err,addres){
        var city = addres[0].city;
        var state = addres[0].statename;
        var pincodeis = addres[0].pincode;
        address=city+"-"+pincodeis+"-"+state;
        var address = new Address({
            address : address
        });
        address.save(function(err){
            if (err){
                console.log("error");
            }else {
                console.log("saved")
            }
        });
    });
    //res.send();
};

//module.exports = combineValidColumns;