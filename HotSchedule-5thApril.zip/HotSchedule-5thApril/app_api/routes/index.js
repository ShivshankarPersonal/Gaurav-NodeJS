var express = require('express');
var router = express.Router();
var combineValidColumns = require("../models/combineValidColumns");

router.get('/combine', combineValidColumns.combine);


module.exports = router;
