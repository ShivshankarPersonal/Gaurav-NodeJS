/**
 * Reading .dbf file
 */
var fileUpload = {};
var log4js = require('log4js');
log4js.configure('./appConfig/log4js.json');
var log = log4js.getLogger("router");

fileUpload.read = function (req, res) {

    try {
        var record;
        var Parser = require('node-dbf');

        var parser = new Parser('./testFiles/dbase_30.dbf');
        //var parser = new Parser(‌‌req.files.file.data);

        parser.on('start', function (p) {
            console.log('dBase file parsing has started');
        });

        parser.on('header', function (h) {
            console.log('dBase file header has been parsed');
        });

        parser.on('record', function (record) {
            console.log(record);
            //res.send("Read .dbf file and CAPTION field value is:-> "+record.CAPTION)

        });

        parser.on('end', function (p) {
            console.log('Finished parsing the dBase file');
        });

        parser.parse();

        res.send("Successfully Read .dbf file");
    } catch (e) {
        log.error("Failed to read file and error is "+e);
    }

};

module.exports = fileUpload;