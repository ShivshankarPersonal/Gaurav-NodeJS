var processDBFFilesInBatch = {};
var later = require('later');
var multer = require('multer');
var upload = multer({dest: 'uploads/'});
var S = require('string');


/**
 * Batch Process Stored Files, remove after completion of processing else throw error
 */

processDBFFilesInBatch.processFilesInBatch = function () {
    var fs = require("fs");
    var obj = JSON.parse(fs.readFileSync('appConfig/bodhiAPI.json', 'utf8'));
    var posFetchCycleTime = obj.posFetchCycleTime;


    var sched = later.parse.recur().every(posFetchCycleTime).minute(),
        t = later.setInterval(processAllDBFFiles, sched);


    //Process All DBF files in an interval of 5min
    function processAllDBFFiles(){
        /**
         * Process Employee Position Table
         */
        var processEmpPosition = require("../controllers/processEmployeePositionData");
        //router.get("/processEmpPosition", processEmpPosition.readDBFnPostToCloud);
        processEmpPosition.readDBFnPostToCloud();
        /**
         * Process process Emp Data Table
         */
        var processEmpData = require("../controllers/processEmpData");
        processEmpData.readDBFnPostToCloud();
        /**
         * Process Employee Position Table
         */
        var processRevenueCenter = require("../controllers/processRevenueCenter");
        processRevenueCenter.readDBFnPostToCloud();
        /**
         * Process process Sales Transaction Table
         */
        var processSalesTransaction = require("../controllers/processSalesTransaction");
        processSalesTransaction.readDBFnPostToCloud();
        /**
         * Process process Sales Category Table
         */
        var processSalesCategory = require("../controllers/processSalesCategory");
        processSalesCategory.readDBFnPostToCloud();
        /**
         * Process process Sales Item Table
         */
        var processSalesItem = require("../controllers/processSalesItem");
        processSalesItem.readDBFnPostToCloud();
        /**
         * Process processSalesJob Table
         */
        var processSalesJob = require("../controllers/processSalesJob");
        processSalesJob.readDBFnPostToCloud();
        /**
         * Process process Time Card Table
         */
        var processTimeCard = require("../controllers/processTimeCard");
        processTimeCard.readDBFnPostToCloud();
    }

    function processDirectory() {
        try {
            var fs = require("fs");
            var path = require("path");
            var p = "temp/DBFFiles/";
            fs.readdir(p, function (err, files) {
                if (err) {
                    throw err;
                }
                files.map(function (file) {
                    return path.join(p, file);
                }).filter(function (file) {
                    return fs.statSync(file).isFile();
                }).forEach(function (file) {
                    console.log("%s (%s)", file, path.extname(file));
                    //Start reading files
                    //check file extension
                    var fileExtension = path.extname(file);
                    //if(fileExtension === '.json'){
                    if (file !== "temp/DBFFiles/.DS_Store") {
                        //read file
                        var jsonfile = require('jsonfile')
                        var util = require('util')
                        console.log(jsonfile.readFileSync(file));
                        //after successfull reading delete file from temp folder
                        fs.unlinkSync(file);
                    }
                });
            });
        } catch (e) {
            console.log("error in this file" + file);
        }
    }
};

module.exports = processDBFFilesInBatch;
