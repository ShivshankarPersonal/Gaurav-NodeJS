/*

 There are some minor modifications to the default Express setup
 Each is commented and marked with [SH] to make them easy to find

 */
/**
 * Require dependencies - Gaurav
 * Author - Gaurav
 * @type {*|exports|module.exports}
 */
var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var mongoose = require("mongoose");

//var busboyBodyParser = require('busboy-body-parser');
// [SH] Require Passport
//var passport = require('passport');

var log4js = require('log4js');
log4js.configure('./appConfig/log4js.json');
var log = log4js.getLogger("app");

// [SH] Bring in the data model
require('./app_api/models/hsStoreJob');
// [SH] Bring in the Passport config after model is defined
require('./app_api/models/hsStoreSchedule');
var salesTransaction = require('./app_api/models/salesTransaction');
require('./app_api/models/storeJob');
//var combineValidColumns = require("./app_api/models/combineValidColumns");


// [SH] Bring in the routes for the API (delete the default routes)
var routesApi = require('./app_api/routes/index');

/**
 * Create express Server
 */
var app = express();

/**
 * Rest full service for accepting DBF file and processing it in batch
 */
var multer = require('multer');
var upload = multer({dest: 'temp/DBFFiles/'});
//var storage = multer.diskStorage({
//    destination: function (req, file, cb) {
//        cb(null, 'temp/DBFFiles/')
//    },
//    filename: function (req, file, cb) {
//        cb(null, file.fieldname + '-' + Date.now())
//    }
//})
//
//var upload = multer({ storage: storage })

var processDBFFilesInBatch = require("./app_api/controllers/processDBFFilesInBatch");
app.post("/uploadFileInBatch",  upload.single('file'), processDBFFilesInBatch.listenAndStoreInDir);
processDBFFilesInBatch.processFilesInBatch();
mongoose.connect("mongodb://localhost/hotSchedule");
log.debug("Connected mongo");


// uncomment after placing your favicon in /public
//app.use(favicon(__dirname + '/public/favicon.ico'));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

//app.use(busboyBodyParser());
app.use(cookieParser());
//app.use(express.static(path.join(__dirname, 'public')));
// [SH] Set the app_client folder to serve static resources
app.use(express.static(path.join(__dirname, 'app_client')));

// [SH] Use the API routes when path starts with /api
app.use('/', routesApi);
//app.get("/combine",combineValidColumns.combine);

app.post("/insertTransaction", salesTransaction.insert);

app.get('/getSalesDtls', function (req, res) {
    res.send("hellow");
});

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handlers


// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
    app.use(function (err, req, res, next) {
        res.status(err.status || 500);
        res.render('error', {
            message: err.message,
            error: err
        });
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    res.send();
    //res.render('error', {
    //    message: err.message,
    //    error: {}
    //});
});


module.exports = app;
