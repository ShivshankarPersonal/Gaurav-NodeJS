var processEmpPosition = {};
var log4js = require('log4js');
log4js.configure('./appConfig/log4js.json');
var log = log4js.getLogger("exception Handling file");
var request = require('request');
var fse = require('fs-extra');
var api = require('bodhi-driver-superagent');
var client = api.createUserClient('gaurav.roy@itcinfotech.com', 'Login@123', 'itcinfotech');
var Parser = require('node-dbf');

/**
 * readDBFnPostToCloud
 * @param req
 * @param res
 */
processEmpPosition.readDBFnPostToCloud = function (req, res) {
    //Read DBF file
    try {

        //Read files from directory
        var fs = require("fs");
        var path = require("path");
        //Path of C Drive
        //var p = "allDBFFiles";
        var p = "/Volumes/StudyMaterials/Workspace/Gaurav/HotSchedule/temp";
        fs.readdirSync(p, function (err, files) {
            if (err) {
                throw err;
            }
            files.map(function (file) {
                return path.join(p, file);
            }).filter(function (file) {
                return fs.statSync(file).isFile();
            }).forEach(function (file) {
                console.log("%s (%s)", file, path.extname(file));
                //Start reading files
                //check file extension
                var fileExtension = path.extname(file);
                //if(fileExtension === '.json'){
                if (file !== "temp/DBFFiles/.DS_Store") {
                    var filename = file.split('/')[1];
                    var createdOn = filename.split('.')[0].substr(-4);
                    var d = new Date();
                    var year = d.getYear().toString().substr(1, 2);
                    var month = parseInt(d.getMonth()) + 1;
                    if (year === createdOn.substr(2, 3) && month === parseInt(createdOn.substr(0, 2))) {
                        fse.copy(file.toString(), 'temp/DBFFiles/' + filename, function (err) {
                            if (err) {
                                return console.error(err)
                            } else {
                                log.log("successfully copied!");
                            }
                        });
                    }
                }
            });
        });

        //Process new directory - dbf files
        var record;
        //var Parser = require('bodhi-dbf');
        var parserEmp = new Parser('./temp/DBFFiles/EMPLOYEE0516.DBF');
        parserEmp.on('start', function (p) {
            log.log('dBase file parsing has started');
        });

        parserEmp.on('header', function (h) {
            log.log('dBase file header has been parsed');
        });


        parserEmp.on('record', function (record) {
            //read login dbf file

            var jsonObj = {
                "external_ids": [{"key": "779"}],
                "birthdate": null,
                "phone_numbers": [null],
                "nickname": "Brandy",
                "name": {
                    "family_name": "shields",
                    "middle_name": null,
                    "given_name": "Brandy",
                    "formatted_name": "Brandy shields"
                },
                "addresses": [
                    {
                        "extended_address": null,
                        "postal_code": null,
                        "region": null,
                        "locality": null,
                        "street_address": null
                    }
                ],
                "sys_id": "56341a35a0143e6da79de73d"
            };

            client.post('resources/Employee', jsonObj, function (err, json, res) {
                console.log(res.statusCode);
                client.get('resources/Employee', function (err, json, res) {
                    console.log(err, res.statusCode, json.length);
                })
            });


            //var parserLogin = new Parser('./temp/DBFFiles/LOGIN0516.DBF');
            ////var parser = new Parser(‌‌req.files.file.data);
            //
            //parserLogin.on('start', function (p) {
            //    //log.log('dBase file parsing has started');
            //});
            //
            //parserLogin.on('header', function (h) {
            //    //log.log('dBase file header has been parsed');
            //});
            //
            //parserLogin.on('record', function (loginRecord) {
            //
            //    //uncomment this later
            //    //var d = new Date();
            //    //var year = d.getYear().toString().substr(1, 2);
            //    //var month = d.getMonth();
            //    //var date = d.getDate().toString();
            //    //var hours = d.getHours();
            //    //var min = d.getMinutes();
            //    //if (record.RAWOUTDATE.substr(0, 4) >= '20' + year && record.RAWOUTDATE.substr(4, 2) >= '0' + (month + 1).toString() && record.RAWOUTDATE.substr(6, 2) >= date && record.RAWOUTTIME.split(':')[0] >= hours.toString() && parseInt(record.RAWOUTTIME.split(':')[1]) >= (min - 5)) {
            //    //    console.log("Only Pushing latest record which are present in added in last 5min and record are : ====");
            //    //    console.log(record);
            //    //
            //    //
            //    //} else {
            //    //    console.log("Already Pushed Records are :====");
            //    //    console.log(record);
            //    //}
            //
            //    if (record.EMP_NO && loginRecord.EMP_NO && record.EMP_NO === loginRecord.EMP_NO) {
            //
            //        console.log(record.HIRE_DATE);
            //        var jsonObj = {
            //            "employee_reference": {
            //                "id": "" + record.EMP_NO,
            //                "name": record.EMP_NAME
            //            },
            //            "store_id": "557605fc4c32e071180a46041119998888",
            //            "status": "" + record.EMP_ACTIVE,
            //            "regular_rate": {
            //                "value": record.EMP_RATE1,
            //                "code": "USD",
            //                "scale": 2
            //            },
            //            "store_reference": {
            //                "id": "2209",
            //                "name": "starz_sioux_falls"
            //            },
            //            "job_reference": {
            //                "id": "" + record.EMP_NO,
            //                "name": "" + loginRecord.JCLASS
            //            },
            //            "employment_period": {
            //                //"from": ""+record.HIRE_DATE,
            //                //"to": null
            //                "from": "2012-10-15T00:00:00.000Z",
            //                "to": null
            //            },
            //            "sys_id": "56341a3ba0143e6da79de7b7"
            //        };
            //
            //        client.post('resources/EmployeePosition', jsonObj, function (err, json, res) {
            //
            //            console.log(res.statusCode);
            //
            //            client.get('resources/EmployeePosition', function (err, json, res) {
            //
            //                console.log(err, res.statusCode, json.length);
            //            })
            //        });
            //    }
            //});
            //parserLogin.on('end', function (p) {
            //    //log.log('Finished parsing the dBase file');
            //});
            //parserLogin.parse();
        });

        parserEmp.on('end', function (p) {
            //log.log('Finished parsing the dBase file');
        });
        parserEmp.parse();


        res.send("Successfully Read .dbf file");
    } catch (e) {
        log.error("Failed to read file and error is " + e);
    }


};

module.exports = processEmpPosition;
