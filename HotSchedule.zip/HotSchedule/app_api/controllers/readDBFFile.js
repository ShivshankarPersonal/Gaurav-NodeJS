/**
 * Reading .dbf file
 */
var fileUpload = {};
var log4js = require('log4js');
log4js.configure('./appConfig/log4js.json');
var log = log4js.getLogger("router");

fileUpload.read = function (req, res) {

    try {
        var record;
        var Parser = require('node-dbf');

        var parser = new Parser('./testFiles/LOGIN90.DBF');
        //var parser = new Parser(‌‌req.files.file.data);

        parser.on('start', function (p) {
            console.log('dBase file parsing has started');
        });

        parser.on('header', function (h) {
            console.log('dBase file header has been parsed');
        });

        parser.on('record', function (record) {
            //console.log(record);
            //res.send("Read .dbf file and CAPTION field value is:-> "+record.CAPTION)
            var d = new Date();
            var year = d.getYear().toString().substr(1, 2);
            var month = d.getMonth();
            var date = d.getDate().toString();
            var hours = d.getHours();
            var min = d.getMinutes();
            if (record.RAWOUTDATE.substr(0, 4) >= '20' + year && record.RAWOUTDATE.substr(4, 2) >= '0' + (month + 1).toString() && record.RAWOUTDATE.substr(6, 2) >= date && record.RAWOUTTIME.split(':')[0] >= hours.toString() && parseInt(record.RAWOUTTIME.split(':')[1]) >= (min - 5)) {
                console.log("Only Pushing latest record which are present in added in last 5min and record are : ====");
                console.log(record);
            }else{
                console.log("Already Pushed Records are :====");
                console.log(record);
            }


        });

        parser.on('end', function (p) {
            console.log('Finished parsing the dBase file');
        });

        parser.parse();

        res.send("Successfully Read .dbf file");
    } catch (e) {
        log.error("Failed to read file and error is " + e);
    }

};

module.exports = fileUpload;