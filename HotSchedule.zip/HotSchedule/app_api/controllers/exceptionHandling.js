var handleException = {};
var log4js = require('log4js');
log4js.configure('./appConfig/log4js.json');
var log = log4js.getLogger("exception Handling file");
handleException.handle = function(req, res){
    try {
        var x = 10;
        var y = 0;
        x/y;

        //user defined exceptions throwing
        if (y === 0) {
            throw Error("divice by zero");
        }
    } catch (e) {
        //log.error("trying to divide with zero"+e)
        log.error(e)
        log.error(req.hostname)
    }
    res.send("raised for host-"+req.hostname);
}

module.exports = handleException;
