var fetchDataFromRMPOS = exports = module.exports;
var log4js = require('log4js');
log4js.configure('./appConfig/log4js.json');
var log = log4js.getLogger("exception Handling file");
var request = require('request');
/**
 * fetch data from POS system and process it - map to HotSchedules cloud
 * @param req
 * @param res
 */
fetchDataFromRMPOS.fetchAndProcessData = function(req, res){
    try {
        var username = 'gaurav.roy@itcinfotech.com';
        var password = 'Login@123';
        var options = {
            //url: 'https://api.bodhi.space:443/itcinfotech/resources/SalesTransaction/Test',
            url : 'https://' + username + ':' + password + '@api.bodhi.space:443/itcinfotech/resources/SalesTransaction/Test',
            headers: {
                'User-Agent': 'request'
            }
        };
        function callback(error, response, body) {
            //if (!error && response.statusCode == 200) {
            if (!error) {
                console.log(body);
                var info = JSON.parse(body);
                console.log(info);

                //Post data to here
                //https://api.bodhi.space:443/itcinfotech/resources/SalesTransaction
                var cloudUserName = 'gaurav.roy@itcinfotech.com';
                var cloudPassword = 'Login@123';
                //var cloudOptions = {
                //    url : 'https://' + cloudUserName + ':' + cloudPasswordbacpro + '@api.bodhi.space:443/itcinfotech/resources/SalesTransaction',
                //    headers: {
                //        'User-Agent': 'request'
                //    }
                //
                //};
                var json = {
                    "store_id": "dtfRU1",
                    "instore_name": "5oVvi1",
                    "display_name": "TnfPG1",
                    "instore_id": "ATMXu1"
                };

                function callbackCloud(){
                    if (!error) {

                    }
                }
                //request(options, callbackCloud);
                request({
                    method: 'POST',
                    preambleCRLF: true,
                    postambleCRLF: true,
                    //uri: 'https://' + cloudUserName + ':' + cloudPassword + '@api.bodhi.space:443/itcinfotech/resources/SalesTransaction',
                    uri: 'https://' + cloudUserName + ':' + cloudPassword + '@api.bodhi.space:443/itcinfotech/resources/RevenueCenter',
                    multipart: {
                        chunked: false,
                        data: [
                            {
                                'content-type': 'application/json',
                                body: JSON.stringify(json)
                            },
                            {body: 'I am an attachment'}
                        ]
                    }
                }, function(error, response, body){
                    if (error) {
                        return console.error('upload failed:', error);
                    }
                    console.log('Upload successful!  Server responded with:', body);
                })
            }
        }
        request(options, callback);
        //request('http://jsonplaceholder.typicode.com/posts/1', function (error, response, body) {
        //    if (!error && response.statusCode == 200) {
        //        // all json data will be here in body, parse it and push to HotSchedules Cloud API
        //        log.info(body);
        //    }
        //});
        res.send('fetched');

    } catch (e) {
        log.log("error in fetchDataFromRMPOS.fetchAndProcessData"+e);
    }
};