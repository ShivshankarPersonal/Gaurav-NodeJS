var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var storeJob = module.exports = {};

/**
 * StoreJob Schema and Collection - Sandhya written
 * @params {String} instore_id - store id
 */
var storeJobSchema = new Schema({
    instore_id : String,
    instore_name : String,
    store_id : String,
    regular_rate : Number,
    doubletime_rate : Number
});
var StoreJob = mongoose.model("StoreJob", storeJobSchema);

/**
 * Employee Schema and Collection
 */
var employeeSchema = new Schema({
    name : String,
    nickname : String,
    birthdate : Date,
    address : [String],
    emails : [String],
    status : String,
    employement_period : Date,
    instore_id : String,
    hr_id : String,
    store : String,
    store_id : String,
    phone_numbers : String
})
var Employee = mongoose.model("Employee", employeeSchema);

/**
 * EmployeePosition Schema and Collection
 */

var EmployeePositionSchema = new Schema({
    store_id : String,
    employee_id : String,
    job_id : String,
    store_reference : String,
    employee_reference : String,
    job_reference : String,
    status : String,
    regular_rate : Number,
    overtime_rate : Number,
    doubletime_rate : Number,
    employment_period : Date
})
var EmployeePosition = mongoose.model("EmployeePosition", EmployeePositionSchema);

/**
 * RevenueCenter Schema and Collection
 */

var revenueCenterSchema = new Schema({
    store_id : String,
    instore_id : String,
    instore_name : String,
    display_name : String
})
var RevenueCenter = mongoose.model("RevenueCenter", revenueCenterSchema);

/**
 * SalesCategory Schema and Collection
 */

var salesCategorySchema = new Schema({
    store_id : String,
    instore_id : String,
    instore_name : String,
    display_name : String
})
var SalesCategory = mongoose.model("SalesCategory", salesCategorySchema);

/**
 * SalesItem Schema and Collection
 */

var salesItemSchema = new Schema({
    store_id : String,
    business_day : String,
    transaction_date : Date,
    amount : Number,
    revenue_category : String,
    sales_category : String,
    employee : String,
    store : String,
    order_id : String,
    transaction_id : String,
    external_ids : [String]
})
var SalesItem1 = mongoose.model("SalesItem1", salesItemSchema);

/**
 * TimeCard Schema and Collection
 */

var TimeCardSchema = new Schema({
    store_id : String,
    job_id : String,
    employee_id : String,
    employee_reference : String,
    job_reference : String,
    store_reference : String,
    business_day : String,
    started_at : String,
    ended_at : String,
    regular_rate : Number,
    overtime_rate : Number,
    doubletime_rate : Number,
    external_ids : [String]
})
var TimeCard1 = mongoose.model("TimeCard1", TimeCardSchema);