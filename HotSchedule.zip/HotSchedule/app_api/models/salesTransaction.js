var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var salesTransaction = module.exports = {};
var salesTransactionSchema = new Schema({
    store_id: {type: String, required: true},
    timestamp: {type: Date},
    business_day: String,
    order_id: String,
    order_number: Number,
    order_opened_at: Date
});
var SalesTransaction = mongoose.model('SalesTransaction', salesTransactionSchema);
salesTransaction.insert = function (req, res) {
    //insert after 20sec (20000 milliseconds) on arrival of dataset insert request
    setTimeout(saveRec, 2000);

    function saveRec() {
        //We can apply logic on input data and we can post to cloud, example is below
        var store_id = 'hotSchedule-' + req.body.a;
        var timestamp = req.body.b;
        var business_day = req.body.c;
        var order_id = req.body.d;
        var order_number = req.body.e;
        var order_opened_at = req.body.f;
        var salesTransaction = new SalesTransaction({
            store_id: store_id, timestamp: timestamp, business_day: business_day,
            order_id: order_id, order_number: order_number, order_opened_at: order_opened_at
        });
        salesTransaction.save(function (err) {
            res.send();
            if (err) {
                console.log("failed" + err);
            } else {
                console.log("inserted record");
            }
        });
    }
};
